The integration test is divided into four phases: planning phase, design phase, implementation phase, and execution phase.

һ��Planning stage
1��Schedule��The completion of the project proposal takes approximately three days and can be completed within one week.
2��Input��Requirements specification, Summary design document, Product development plan roadmap
3��Entry conditions��The summary design document has been reviewed.
4��Activity steps��a.Set the test object and test scope.
	            b.Evaluate the number and difficulty of the test object to be tested, ie the workload.
	            c.Determine the role division and task.
	            d.Identify the time, task, constraints and other conditions of each stage of the test.
                            e.Consider certain risk analysis and contingency plans.
                            f.Consider and prepare the test tools, test instruments, environment and other resources needed for integration testing.
                            g.Consider the strength and depth of external technical support and related training arrangements.
                            h.Define test completion criteria.
5��Output��Integration Test Plan
6��Export conditions��The integration test plan passes the baseline review during the summary design phase.

����Design phase
1��Schedule��The detailed design phase begins.
2��Input��Requirements specification, Summary design, Integration test plan
3��Entry conditions��The summary design baseline is reviewed.
4��Activity steps��a.Structural analysis of the measured object.
	            b.Integrated test module analysis.
	            c.Integrated test interface analysis.
	            d.Integrated test strategy analysis.
5��Output��Integrated test design (plan)
6��Export conditions��The integrated test design is reviewed by a detailed design baseline.

����Implementation phase
1��Schedule��It is done after the coding phase begins.
2��Input��Requirements specification, Summary design, Integration test plan, Integration test design
3��Entry conditions��Detailed design stage.
4��Output��Integrated Test Case Integration Test Procedure Integration Test Code Integration Test Script Integration Test Tool.
5��Export conditions��Test cases and test procedures are reviewed by the coding phase baseline.

�ġ�Execution phase
1) Schedule: After the unit test has been completed, you can start the integration test.
2) Input: Requirements specification, Summary design, Integration test, Plan integration height design
3) Entry conditions: The unit testing phase has passed the baseline review.
4) Activity steps: Perform integration test case regression integration test case writing integration test report.
5) Output: Integration Test Report
6) Export conditions: The integration test report passes the integration test phase baseline review.