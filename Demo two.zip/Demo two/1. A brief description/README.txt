1. Our team uses myeclipse to write java code, the jdk version is 1.7, and the server uses the Tomcat 8.5 version that comes with myeclipse.
2. Our team provides usable files on GitHub
3. The parameters that need to be entered during project operation are the user's account number, password and verification code.
	3.1.int type, a numeric type for the underlying machine, used for numeric
	3.2.string type, which guides a constant (such as the string "abc"), can not be changed after the object is constructed.
	3.3.public final class declares a class, followed by the class name
	3.4.public static void Modifies a static method, which belongs to a class and is called directly using the class name and method name.
	3.5.byte is a byte, consisting of 8 bits of binary
4. Our team has created two users in the project. The first user's account: wally; password: 123456. The second user's account: carr; password: 123456.
5. The allowable values of all parameters that need to be entered when running this project are 0, 1, 2, 3, 4, 5, 6, 7, 8, 9.