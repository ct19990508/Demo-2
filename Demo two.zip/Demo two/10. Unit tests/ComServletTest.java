package com.action.test;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.easymock.EasyMock;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.action.AdminAction;
import com.action.ComServlet;

//import sun.text.normalizer.IntTrie;

import com.bean.ComBean;
import com.bean.ExpressageBean;
import com.util.Constant;
import com.util.SmartFile;
import com.util.SmartUpload;
import com.util.SmartUploadException;
/**
 * 
 * ����ҵ�� �����ӿ����Ϣ�Ȳ��������������
 * 
 * @author Ray
 *
 */
public class ComServletTest extends HttpServlet {

	private ServletConfig config;
	public ComServletTest() {
		super();
	}

	final public void init(ServletConfig config) throws ServletException
    {
        this.config = config;  
    }

    final public ServletConfig getServletConfig()
    {
        return config;
    }
	public void destroy() {
		super.destroy(); // Just puts "destroy" string in log
		// Put your code here
	}

	/**
	 * The doGet method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to get.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doPost(request,response);
	}

	/**
	 * The doPost method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to post.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {}

	/**
	 * Initialization of the servlet. <br>
	 *
	 * @throws ServletException if an error occure
	 */
	public void init() throws ServletException {
		// Put your code here
	}

    private HttpServletRequest request;
    private HttpServletResponse response;
    private HttpSession session;
 
    @Before
    public void before() throws Exception {
        // ����request��response��Mock
        request = EasyMock.createMock(HttpServletRequest.class);
        response = EasyMock.createMock(HttpServletResponse.class);
        session = EasyMock.createMock(HttpSession.class);
    }
 
    @After
    public void after() throws Exception {
    }

    
    @Test
    public void testExecute() throws Exception {
    	AdminAction service =new AdminActionTest();
 
        EasyMock.expect(request.getParameter("id")).andReturn("sa225").once();    //����ʹ�ò���
        EasyMock.expect(request.getParameter("titile")).andReturn("test").times(1);  //�������õĴ���
 
        EasyMock.replay(request);   //�����������
 
        service.doPost(request, response);
 
    
    }

}
