package com.action.test;
/**
 * Administrator login Add Modify Delete Delete login log
 
 */
import java.io.IOException;
import java.util.List;
import java.util.StringTokenizer;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.easymock.EasyMock;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.action.AdminAction;
import com.bean.AdminBean;
import com.bean.PermissionBean;
import com.bean.RoleBean;
import com.bean.SystemBean;

import com.util.Constant;
import com.util.MD5;

public class AdminActionTest extends AdminAction {

	/**
	 * Constructor of the object.
	 */
	public AdminActionTest() {
		super();
	}

	/**
	 * Destruction of the servlet. <br>
	 */
	public void destroy() {
		super.destroy(); // Just puts "destroy" string in log
		// Put your code here
	}

	/**
	 * The doGet method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to get.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doPost(request,response);
	}

	/**
	 * The doPost method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to post.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
	}

	/**
	 * Initialization of the servlet. <br>
	 *
	 * @throws ServletException if an error occure
	 */
	public void init() throws ServletException {
		// Put your code here
	}

	
	    private HttpServletRequest request;
	    private HttpServletResponse response;
	    private HttpSession session;
	 
	    @Before
	    public void before() throws Exception {
	        // ����request��response��Mock
	        request = EasyMock.createMock(HttpServletRequest.class);
	        response = EasyMock.createMock(HttpServletResponse.class);
	        session = EasyMock.createMock(HttpSession.class);
	    }
	 
	    @After
	    public void after() throws Exception {
	    }

	    
	    @Test
	    public void testExecute() throws Exception {
	    	AdminAction service =new AdminActionTest();
	 
	        EasyMock.expect(request.getParameter("usename")).andReturn("UserRegisterTest").once();    //����ʹ�ò���
	        EasyMock.expect(request.getParameter("passwrod")).andReturn("testtest").times(1);  //�������õĴ���
	 
	        EasyMock.replay(request);   //�����������
	 
	        service.doPost(request, response);
	 
	    
	    }


}
