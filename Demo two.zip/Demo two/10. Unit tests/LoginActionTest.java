package com.action.test;

/**
 * ǰ̨��Ա��½ �˳�
 * 
 */

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.easymock.EasyMock;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.action.ExpressageManagerServlet;
import com.action.LoginAction;
import com.bean.MemberBean;
import com.util.Constant;
import com.util.Filter;

public class LoginActionTest extends LoginAction {





	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doPost(request,response);
	}


	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {}

	
	
	 private HttpServletRequest request;
	    private HttpServletResponse response;
	    private HttpSession session;
	 
	    @Before
	    public void before() throws Exception {
	        // ����request��response��Mock
	        request = EasyMock.createMock(HttpServletRequest.class);
	        response = EasyMock.createMock(HttpServletResponse.class);
	        session = EasyMock.createMock(HttpSession.class);
	    }
	 
	    @After
	    public void after() throws Exception {
	    }

	    
	    @Test
	    public void testExecute() throws Exception {
	    	LoginAction service =new LoginActionTest();
	    
	        EasyMock.expect(request.getParameter("reg_user")).andReturn("sa").once();    //����ʹ�ò���
	        EasyMock.expect(request.getParameter("reg_pwd")).andReturn("sasa").times(1);  //�������õĴ���
	        EasyMock.expect(request.getParameter("reg_type")).andReturn("one").once();    //����ʹ�ò���
	        EasyMock.expect(request.getParameter("method")).andReturn("reg").times(1);  //�������õĴ���
	 
	        EasyMock.replay(request);   //�����������
	 
	        service.doPost(request, response);
	 
	    
	    }


}
