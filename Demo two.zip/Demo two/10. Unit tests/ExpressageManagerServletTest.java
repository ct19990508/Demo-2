package com.action.test;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.easymock.EasyMock;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.action.AdminAction;
import com.action.ExpressageManagerServlet;
import com.bean.ExpressageBean;
import com.bean.MemberBean;
import com.bean.PermissionBean;
import com.bean.RoleBean;
import com.bean.UserToExpressageBean;
import com.util.Common;

public class ExpressageManagerServletTest extends ExpressageManagerServlet {


	/**
	 * The doGet method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to get.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		}

	/**
	 * The doPost method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to post.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		this.doGet(request, response);

	}

	
	    private HttpServletRequest request;
	    private HttpServletResponse response;
	    private HttpSession session;
	 
	    @Before
	    public void before() throws Exception {
	        // ����request��response��Mock
	        request = EasyMock.createMock(HttpServletRequest.class);
	        response = EasyMock.createMock(HttpServletResponse.class);
	        session = EasyMock.createMock(HttpSession.class);
	    }
	 
	    @After
	    public void after() throws Exception {
	    }

	    
	    @Test
	    public void testExecute() throws Exception {
	    	ExpressageManagerServlet service =new ExpressageManagerServletTest();
	 
	        EasyMock.expect(request.getParameter("action")).andReturn("UserRegisterTest").once();    //����ʹ�ò���
	        EasyMock.expect(request.getParameter("id")).andReturn("sa522").times(1);  //�������õĴ���
	 
	        EasyMock.replay(request);   //�����������
	 
	        service.doPost(request, response);
	 
	    
	    }

	
}
