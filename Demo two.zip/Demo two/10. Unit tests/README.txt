Unit Test
First Added unit test
������We add tests to the public methods of the LoginAction, ComServlet, AdminAction, ExpressageMangerServelet, and MemberAction public classes.
������Second, unit test each of the constructors and public properties.
������Finally, all units of our team are tested separately.
Second, the unit test each code
Login
package com.action.test;

/**
 * ǰ̨��Ա��½ �˳�
 * 
 */

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.easymock.EasyMock;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.action.ExpressageManagerServlet;
import com.action.LoginAction;
import com.bean.MemberBean;
import com.util.Constant;
import com.util.Filter;

public class LoginActionTest extends LoginAction {





	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doPost(request,response);
	}


	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {}

	
	
	 private HttpServletRequest request;
	    private HttpServletResponse response;
	    private HttpSession session;
	 
	    @Before
	    public void before() throws Exception {
	        // ����request��response��Mock
	        request = EasyMock.createMock(HttpServletRequest.class);
	        response = EasyMock.createMock(HttpServletResponse.class);
	        session = EasyMock.createMock(HttpSession.class);
	    }
	 
	    @After
	    public void after() throws Exception {
	    }

	    
	    @Test
	    public void testExecute() throws Exception {
	    	LoginAction service =new LoginActionTest();
	    
	        EasyMock.expect(request.getParameter("reg_user")).andReturn("sa").once();    //����ʹ�ò���
	        EasyMock.expect(request.getParameter("reg_pwd")).andReturn("sasa").times(1);  //�������õĴ���
	        EasyMock.expect(request.getParameter("reg_type")).andReturn("one").once();    //����ʹ�ò���
	        EasyMock.expect(request.getParameter("method")).andReturn("reg").times(1);  //�������õĴ���
	 
	        EasyMock.replay(request);   //�����������
	 
	        service.doPost(request, response);
	 
	    
	    }


}

ComServlet
package com.action.test;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.easymock.EasyMock;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.action.AdminAction;
import com.action.ComServlet;

//import sun.text.normalizer.IntTrie;

import com.bean.ComBean;
import com.bean.ExpressageBean;
import com.util.Constant;
import com.util.SmartFile;
import com.util.SmartUpload;
import com.util.SmartUploadException;
/**
 * 
 * ����ҵ�� �����ӿ����Ϣ�Ȳ��������������
 * 
 * @author Ray
 *
 */
public class ComServletTest extends HttpServlet {

	private ServletConfig config;
	public ComServletTest() {
		super();
	}

	final public void init(ServletConfig config) throws ServletException
    {
        this.config = config;  
    }

    final public ServletConfig getServletConfig()
    {
        return config;
    }
	public void destroy() {
		super.destroy(); // Just puts "destroy" string in log
		// Put your code here
	}

	/**
	 * The doGet method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to get.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doPost(request,response);
	}

	/**
	 * The doPost method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to post.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {}

	/**
	 * Initialization of the servlet. <br>
	 *
	 * @throws ServletException if an error occure
	 */
	public void init() throws ServletException {
		// Put your code here
	}

    private HttpServletRequest request;
    private HttpServletResponse response;
    private HttpSession session;
 
    @Before
    public void before() throws Exception {
        // ����request��response��Mock
        request = EasyMock.createMock(HttpServletRequest.class);
        response = EasyMock.createMock(HttpServletResponse.class);
        session = EasyMock.createMock(HttpSession.class);
    }
 
    @After
    public void after() throws Exception {
    }

    
    @Test
    public void testExecute() throws Exception {
    	AdminAction service =new AdminActionTest();
 
        EasyMock.expect(request.getParameter("id")).andReturn("sa225").once();    //����ʹ�ò���
        EasyMock.expect(request.getParameter("titile")).andReturn("test").times(1);  //�������õĴ���
 
        EasyMock.replay(request);   //�����������
 
        service.doPost(request, response);
 
    
    }

}

AdminAction
package com.action.test;
/**
 * Administrator login Add Modify Delete Delete login log
 
 */
import java.io.IOException;
import java.util.List;
import java.util.StringTokenizer;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.easymock.EasyMock;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.action.AdminAction;
import com.bean.AdminBean;
import com.bean.PermissionBean;
import com.bean.RoleBean;
import com.bean.SystemBean;

import com.util.Constant;
import com.util.MD5;

public class AdminActionTest extends AdminAction {

	/**
	 * Constructor of the object.
	 */
	public AdminActionTest() {
		super();
	}

	/**
	 * Destruction of the servlet. <br>
	 */
	public void destroy() {
		super.destroy(); // Just puts "destroy" string in log
		// Put your code here
	}

	/**
	 * The doGet method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to get.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doPost(request,response);
	}

	/**
	 * The doPost method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to post.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
	}

	/**
	 * Initialization of the servlet. <br>
	 *
	 * @throws ServletException if an error occure
	 */
	public void init() throws ServletException {
		// Put your code here
	}

	
	    private HttpServletRequest request;
	    private HttpServletResponse response;
	    private HttpSession session;
	 
	    @Before
	    public void before() throws Exception {
	        // ����request��response��Mock
	        request = EasyMock.createMock(HttpServletRequest.class);
	        response = EasyMock.createMock(HttpServletResponse.class);
	        session = EasyMock.createMock(HttpSession.class);
	    }
	 
	    @After
	    public void after() throws Exception {
	    }

	    
	    @Test
	    public void testExecute() throws Exception {
	    	AdminAction service =new AdminActionTest();
	 
	        EasyMock.expect(request.getParameter("usename")).andReturn("UserRegisterTest").once();    //����ʹ�ò���
	        EasyMock.expect(request.getParameter("passwrod")).andReturn("testtest").times(1);  //�������õĴ���
	 
	        EasyMock.replay(request);   //�����������
	 
	        service.doPost(request, response);
	 
	    
	    }


}





ExpressageMangerServelet
package com.action.test;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.easymock.EasyMock;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.action.AdminAction;
import com.action.ExpressageManagerServlet;
import com.bean.ExpressageBean;
import com.bean.MemberBean;
import com.bean.PermissionBean;
import com.bean.RoleBean;
import com.bean.UserToExpressageBean;
import com.util.Common;

public class ExpressageManagerServletTest extends ExpressageManagerServlet {


	/**
	 * The doGet method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to get.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		}

	/**
	 * The doPost method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to post.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		this.doGet(request, response);

	}

	
	    private HttpServletRequest request;
	    private HttpServletResponse response;
	    private HttpSession session;
	 
	    @Before
	    public void before() throws Exception {
	        // ����request��response��Mock
	        request = EasyMock.createMock(HttpServletRequest.class);
	        response = EasyMock.createMock(HttpServletResponse.class);
	        session = EasyMock.createMock(HttpSession.class);
	    }
	 
	    @After
	    public void after() throws Exception {
	    }

	    
	    @Test
	    public void testExecute() throws Exception {
	    	ExpressageManagerServlet service =new ExpressageManagerServletTest();
	 
	        EasyMock.expect(request.getParameter("action")).andReturn("UserRegisterTest").once();    //����ʹ�ò���
	        EasyMock.expect(request.getParameter("id")).andReturn("sa522").times(1);  //�������õĴ���
	 
	        EasyMock.replay(request);   //�����������
	 
	        service.doPost(request, response);
	 
	    
	    }

	
}

MemberAction
package com.action.test;

/**
 * ��Աע�ᡢ�޸����ϵ�
 * @author Administrator
 *
 */


import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.easymock.EasyMock;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.action.ExpressageManagerServlet;
import com.action.MemberAction;
import com.bean.MemberBean;
import com.bean.SystemBean;
import com.util.Constant;
import com.util.Filter;
import com.util.MD5;

public class MemberActionTest extends MemberAction {

	
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doPost(request,response);
	}

	/**
	 * The doPost method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to post.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

	}
//		else if(method.equals("PREG")){//���˻�Ա��ϸ����
//			String username = Filter.escapeHTMLTags(request.getParameter("username").trim());
//			String password = Filter.escapeHTMLTags(request.getParameter("password").trim());
//			String type = "person";
//			String realname = Filter.escapeHTMLTags(request.getParameter("realname").trim());
//			String sex = Filter.escapeHTMLTags(request.getParameter("sex").trim());
//			String sheng = Filter.escapeHTMLTags(request.getParameter("sheng").trim());
//			String city = Filter.escapeHTMLTags(request.getParameter("city").trim());
//			String bir = Filter.escapeHTMLTags(request.getParameter("bir").trim());
//			String telphone = Filter.escapeHTMLTags(request.getParameter("telphone").trim());
//			String email = Filter.escapeHTMLTags(request.getParameter("email").trim());
//			String question = Filter.escapeHTMLTags(request.getParameter("question").trim());
//			String answer = Filter.escapeHTMLTags(request.getParameter("answer").trim());
//			String address = Filter.escapeHTMLTags(request.getParameter("address").trim());
	
    private HttpServletRequest request;
    private HttpServletResponse response;
    private HttpSession session;
 
    @Before
    public void before() throws Exception {
        // ����request��response��Mock
        request = EasyMock.createMock(HttpServletRequest.class);
        response = EasyMock.createMock(HttpServletResponse.class);
        session = EasyMock.createMock(HttpSession.class);
    }
 
    @After
    public void after() throws Exception {
    }

    
    @Test
    public void testExecute() throws Exception {
    	ExpressageManagerServlet service =new ExpressageManagerServletTest();
 
        EasyMock.expect(request.getParameter("username")).andReturn("sa").once();    //����ʹ�ò���
        EasyMock.expect(request.getParameter("password")).andReturn("sasa").times(1);  //�������õĴ���
        EasyMock.expect(request.getParameter("realname")).andReturn("sasasa").once();    //����ʹ�ò���
        EasyMock.expect(request.getParameter("sex")).andReturn("man").times(1);  //�������õĴ���
        EasyMock.expect(request.getParameter("sheng")).andReturn("175").once();    //����ʹ�ò���
        EasyMock.expect(request.getParameter("city")).andReturn("changsha-hunan").times(1);  //�������õĴ���
        EasyMock.expect(request.getParameter("bir")).andReturn("UserRegisterTest").once();    //����ʹ�ò���
        EasyMock.expect(request.getParameter("telphone")).andReturn("18884930129").times(1);  //�������õĴ���
        EasyMock.expect(request.getParameter("email")).andReturn("8859693@qq.com").once();    //����ʹ�ò���
        EasyMock.expect(request.getParameter("question")).andReturn("address").times(1);  //�������õĴ���
        EasyMock.expect(request.getParameter("answer")).andReturn("changsha").once();    //����ʹ�ò���
        EasyMock.expect(request.getParameter("address")).andReturn("changsha").times(1);  //�������õĴ���
        
 
        EasyMock.replay(request);   //�����������
 
        service.doPost(request, response);
 
    
    }

}

Code coverage
������First, we used boundary condition data, null data, and incorrectly formatted data to improve our coverage.
������In the application of the boundary condition data, the maximum value and the minimum value of the value type data are mainly tested, and the data exceeding the boundary is tested as a test condition at the time of testing.
������Empty data: Tests if there is a null value.
������Incorrectly formatted data: Test data or structural objects of some reference types to see if they are formatted correctly.