package com.action.test;

/**
 * ��Աע�ᡢ�޸����ϵ�
 * @author Administrator
 *
 */


import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.easymock.EasyMock;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.action.ExpressageManagerServlet;
import com.action.MemberAction;
import com.bean.MemberBean;
import com.bean.SystemBean;
import com.util.Constant;
import com.util.Filter;
import com.util.MD5;

public class MemberActionTest extends MemberAction {

	
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doPost(request,response);
	}

	/**
	 * The doPost method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to post.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

	}
//		else if(method.equals("PREG")){//���˻�Ա��ϸ����
//			String username = Filter.escapeHTMLTags(request.getParameter("username").trim());
//			String password = Filter.escapeHTMLTags(request.getParameter("password").trim());
//			String type = "person";
//			String realname = Filter.escapeHTMLTags(request.getParameter("realname").trim());
//			String sex = Filter.escapeHTMLTags(request.getParameter("sex").trim());
//			String sheng = Filter.escapeHTMLTags(request.getParameter("sheng").trim());
//			String city = Filter.escapeHTMLTags(request.getParameter("city").trim());
//			String bir = Filter.escapeHTMLTags(request.getParameter("bir").trim());
//			String telphone = Filter.escapeHTMLTags(request.getParameter("telphone").trim());
//			String email = Filter.escapeHTMLTags(request.getParameter("email").trim());
//			String question = Filter.escapeHTMLTags(request.getParameter("question").trim());
//			String answer = Filter.escapeHTMLTags(request.getParameter("answer").trim());
//			String address = Filter.escapeHTMLTags(request.getParameter("address").trim());
	
    private HttpServletRequest request;
    private HttpServletResponse response;
    private HttpSession session;
 
    @Before
    public void before() throws Exception {
        // ����request��response��Mock
        request = EasyMock.createMock(HttpServletRequest.class);
        response = EasyMock.createMock(HttpServletResponse.class);
        session = EasyMock.createMock(HttpSession.class);
    }
 
    @After
    public void after() throws Exception {
    }

    
    @Test
    public void testExecute() throws Exception {
    	ExpressageManagerServlet service =new ExpressageManagerServletTest();
 
        EasyMock.expect(request.getParameter("username")).andReturn("sa").once();    //����ʹ�ò���
        EasyMock.expect(request.getParameter("password")).andReturn("sasa").times(1);  //�������õĴ���
        EasyMock.expect(request.getParameter("realname")).andReturn("sasasa").once();    //����ʹ�ò���
        EasyMock.expect(request.getParameter("sex")).andReturn("man").times(1);  //�������õĴ���
        EasyMock.expect(request.getParameter("sheng")).andReturn("175").once();    //����ʹ�ò���
        EasyMock.expect(request.getParameter("city")).andReturn("changsha-hunan").times(1);  //�������õĴ���
        EasyMock.expect(request.getParameter("bir")).andReturn("UserRegisterTest").once();    //����ʹ�ò���
        EasyMock.expect(request.getParameter("telphone")).andReturn("18884930129").times(1);  //�������õĴ���
        EasyMock.expect(request.getParameter("email")).andReturn("8859693@qq.com").once();    //����ʹ�ò���
        EasyMock.expect(request.getParameter("question")).andReturn("address").times(1);  //�������õĴ���
        EasyMock.expect(request.getParameter("answer")).andReturn("changsha").once();    //����ʹ�ò���
        EasyMock.expect(request.getParameter("address")).andReturn("changsha").times(1);  //�������õĴ���
        
 
        EasyMock.replay(request);   //�����������
 
        service.doPost(request, response);
 
    
    }

}
