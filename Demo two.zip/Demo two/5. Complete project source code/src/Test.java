import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Test {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");           
		Connection conn = DriverManager.getConnection("jdbc:sqlserver://localhost:1433;databasename=qczl","sa","123456");
		System.out.println(conn);

	}

}
